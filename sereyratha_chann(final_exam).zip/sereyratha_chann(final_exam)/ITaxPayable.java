package final_exam;

public interface ITaxPayable {
	double calulateNetSalary();
	
}
