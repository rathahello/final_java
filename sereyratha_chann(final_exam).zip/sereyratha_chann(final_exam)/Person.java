package final_exam;

public class Person {
	String name;
	double nbOfSleepHours;
	
	public Person(String name, double nbOfSleepHours) {
		this.name = name;
		this.nbOfSleepHours = nbOfSleepHours;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getNbOfSleepHours() {
		return nbOfSleepHours;
	}
	public void setNbOfSleepHours(double nbOfSleepHours) {
		this.nbOfSleepHours = nbOfSleepHours;
	}
	public void showSleepQuality(){
			
	}
}
